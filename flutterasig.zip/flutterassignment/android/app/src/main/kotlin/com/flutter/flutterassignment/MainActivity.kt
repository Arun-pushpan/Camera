package com.flutter.flutterassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

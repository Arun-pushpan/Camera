import 'package:flutter/material.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'package:torch_light/torch_light.dart';
 class Torchlight extends StatefulWidget {
   const Torchlight({Key? key}) : super(key: key);

   @override
   State<Torchlight> createState() => _TorchlightState();
 }

 class _TorchlightState extends State<Torchlight> {
   @override
   Widget build(BuildContext context) {
     return Scaffold(
       appBar:AppBar(
         title: Text("Flashlight"),
       ),
       body: Center(
         child: Column(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             ToggleSwitch(
               minWidth: 90.0,
               cornerRadius: 20.0,
               activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
               activeFgColor: Colors.white,
               inactiveBgColor: Colors.grey,
               inactiveFgColor: Colors.white,
               initialLabelIndex: 1,
               totalSwitches: 2,
               labels: ['On', 'Off',],
               radiusStyle: true,
               onToggle: (index) {
                 print('switched to: $_turnOn(context)');
                 print('switched to:$_turnOff(context)');
               },
             ),
             // ElevatedButton(
             //     onPressed: (){
             //      _turnON(context);
             //     }, child:Text("Turn ON")),
             // ElevatedButton(onPressed: (){}
             //     , child: Text("Turn OFF")),
           ],
         ),
       ),
     );
   }
   Future<void>_turnOn(BuildContext context)async{
     try{
       await TorchLight.enableTorch();
     }
     on Exception catch(_){
       _showError('Could not enable flashlight',context);
     }
   }
   Future<void>_turnOff(BuildContext context)async{
     try{
       await TorchLight.disableTorch();
     }
     on Exception catch(_){
       _showError('could not disable flashlight',context);
     }
   }
   void _showError(String mes,BuildContext context){
     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(mes)));
   }
 }

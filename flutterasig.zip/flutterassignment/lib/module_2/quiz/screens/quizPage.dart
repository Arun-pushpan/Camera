import 'package:flutter/material.dart';
import 'package:flutterassignment/module_2/quiz/screens/quizhome.dart';
import 'package:flutterassignment/module_2/quiz/screens/result.dart';
class Quizapp extends StatefulWidget {
   Quizapp({Key? key}) : super(key: key);

  @override
  State<Quizapp> createState() => _QuizappState();

}

class _QuizappState extends State<Quizapp> {
  final  _questions= const[
  {
    "questionText": 'Q1. who created flutter?',
    'answers': [
      {'text': 'facebook', 'score': -2},
      {'text': 'Adobe', 'score': -2},
      {'text': 'Google', 'score': 10},
      {'text': 'Microsoft', 'score': -2},

    ]
  },
    {
  "questionText": 'Q2. Which language used in flutter?',
  'answers': [
  {'text': 'DART', 'score': 10},
  {'text': 'JAVA', 'score': -2},
  {'text': 'PHP', 'score': -2},
  {'text': 'HTML', 'score': -2},

  ]
},
    {
      'questionText': 'Q3. Who created Dart programing language?',
      'answers': [
        {'text': 'Lars Bak and Kasper Lund', 'score': 10},
        {'text': 'Brendan Eich', 'score': -2},
        {'text': 'Bjarne Stroustrup', 'score': -2},
        {'text': 'Jeremy Ashkenas', 'score': -2},

      ]
    },
    {
      'questionText': 'Q4. What is Flutter?',
      'answers': [
        {'text': 'Android Development Kit', 'score': -2},
        {'text': 'IOS Development Kit', 'score': -2},
        {'text': 'Web Development Kit', 'score': -2},
        {
          'text':
          'SDK to build beautiful IOS, Android, Web & Desktop Native Apps',
          'score': 10
        },
      ],
    },
    {
      'questionText':
      'Q5. Is Flutter for Web and Desktop available in stable version?',
      'answers': [
        {
          'text': 'Yes',
          'score': -2,
        },
        {'text': 'No', 'score': 10},
      ],
    },
  ];
  var _questionIndex = 0;
  var _totalScore = 0;

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
    });
  }

  void _answerQuestion(int score) {
    _totalScore += score;

    setState(() {
      _questionIndex = _questionIndex + 1;
    });
    // ignore: avoid_print
    print(_questionIndex);
    if (_questionIndex < _questions.length) {
      // ignore: avoid_print
      print('We have more questions!');
    } else {
      // ignore: avoid_print
      print('No more questions!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
      appBar: AppBar(
        title: const Text('Quiz App'),
        backgroundColor: const Color(0xFF00E676),
      ),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: _questionIndex < _questions.length
            ? Quiz(
          answerQuestion: _answerQuestion,
          questionIndex: _questionIndex,
          questions: _questions,
        ) //Quiz
            : Result(_totalScore, _resetQuiz),
      ),
      )//Padding
    );
  }
}

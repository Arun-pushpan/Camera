import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '';
class Call extends StatefulWidget {
  const Call({Key? key}) : super(key: key);

  @override
  State<Call> createState() => _CallState();
}

class _CallState extends State<Call> {
  String _phone='';
  @override
  Widget build(BuildContext context) {
    return Form(
      child: Scaffold(
        body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20,top: 30,right: 20,bottom: 20),
                  child: TextFormField(
                    onChanged: (String text)=>_phone=text,
                    decoration:InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "Enter the Phone Number",
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                      label: Text(
                        "Number",
                        style:
                        TextStyle(color: Colors.black, fontSize: 22),
                      ),
                    ),
                  ),
                ),
                ElevatedButton(

                  onPressed: (){
                    launch('tel:$_phone');
                  },
                  child: Text("Call",),
                ),
              ]
          ),
        ),
      ),
    );
  }
}
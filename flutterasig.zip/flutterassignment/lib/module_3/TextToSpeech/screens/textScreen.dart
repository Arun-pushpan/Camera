import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
class Textspeech extends StatefulWidget {
  const Textspeech({Key? key}) : super(key: key);

  @override
  State<Textspeech> createState() => _TextspeechState();
}

class _TextspeechState extends State<Textspeech> {
  final FlutterTts tts=FlutterTts();
  final TextEditingController controller=TextEditingController(text: "Hello Arun");
  Home(){
    tts.setLanguage('Eng');
    tts.setPitch(1.0);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: controller,
          ),
          ElevatedButton(
              onPressed: (){
                tts.speak(controller.text);
              },
              child: Text("speak"))
        ],
      ),
    );
  }
}

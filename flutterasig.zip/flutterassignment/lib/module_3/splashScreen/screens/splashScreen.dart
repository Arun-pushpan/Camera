import 'package:flutter/material.dart';
import 'package:splashscreen/splashscreen.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SplashScreen"),
      ),
    );
  }
}
  class SplashScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
  return Padding(
  padding: const EdgeInsets.only(left: 10 ,top: 60,right: 10,bottom: 10),
  child: SplashScreen(
  seconds: 10,
  navigateAfterSeconds:  Login(),
  backgroundColor: Colors.black,
  title: const Text('Explore  World'
  ,textScaleFactor: 2,
  style: TextStyle(fontWeight: FontWeight.w900,color: Colors.white,
  fontSize:25),),

  image:  Image.asset('assets/img17.jpg'),

  loadingText: Text("Loading",

  style: TextStyle(color: Colors.yellow,fontWeight: FontWeight.w700,fontSize: 25),),
  photoSize: 150.0,
  loaderColor: Colors.red,
  ),
  );
  }
  }



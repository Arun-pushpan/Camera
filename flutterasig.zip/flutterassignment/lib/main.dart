import 'package:flutter/material.dart';
import 'package:flutterassignment/module_2/calculator/screens/calculatorPage.dart';
import 'package:flutterassignment/module_2/flashlight/screens/flashlightPage.dart';
import 'package:flutterassignment/module_2/quiz/screens/quizPage.dart';
import 'package:flutterassignment/module_2/todo/screens/todolist.dart';
import 'package:flutterassignment/module_2/url_launcher/homePage.dart';
import 'package:torch_light/torch_light.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.yellow,

        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      debugShowCheckedModeBanner: true,
      home:TodoApp(),
    );
  }
}


// import 'package:flutter/material.dart';
//
// import 'module_2/url_launcher/homePage.dart';
// import 'module_2/url_launcher/screens/call.dart';
// import 'module_2/url_launcher/screens/mail.dart';
// import 'module_2/url_launcher/screens/sms.dart';
// import 'module_2/url_launcher/screens/web.dart';
//
//
// enum Menu { itemOne, itemTwo, itemThree, itemFour }
// void main() {
//   runApp(MyApp());
// }
// class MyApp extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       routes: {
//         '/calls': (context) => const Call(),
//         '/sms': (context) => const Sms(),
//         '/mails': (context) => const Mail(),
//         '/webs': (context) => const Website()
//       },
//       title: 'Flutter Demo',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: Myhome(),
//     );
//   }
// }
